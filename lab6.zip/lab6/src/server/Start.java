package server;
import server.commands.*;
import server.utility.*;


/**
 * Main server class. Creates all server instances.
 *
 * @author Sviridov Dmitry and Orlov Egor.
 */
public class Start {
    public static final int PORT = 1821;
    public static final int CONNECTION_TIMEOUT = 60 * 1000;
    public static final String ENV_VARIABLE = "LABA";
    public static Logger logger = LogManager.getLogger("ServerLogger");

    public static void main(String[] args) {
        FileHelper fileHelper = new FileHelper(ENV_VARIABLE);
        CollectionManager collectionManager = new CollectionManager(fileHelper);
        CommandManager commandManager = new CommandManager(new HelpCommand(), new InfoCommand(collectionManager),
                new ShowCommand(collectionManager), new AddElementCommand(collectionManager, ticketChecker),
                new UpdateIdCommand(collectionManager, ticketChecker), new RemoveById(collectionManager),
                new Clear(collectionManager), new Exit(), new AddIfMax(collectionManager, ticketChecker),
                new RemoveGreater(collectionManager, ticketChecker), new History(), new FilterContainsName(collectionManager),
                new FilterLessPrice(collectionManager, ticketChecker), new DiscountInAscendingOrder(collectionManager, ticketChecker),
                new SaveCommand(collectionManager), new ExecuteScriptCommand());
        RequestHandler requestHandler = new RequestHandler(commandManager);
        Server server = new Server(PORT, CONNECTION_TIMEOUT, requestHandler);
        server.run();
    }
}
