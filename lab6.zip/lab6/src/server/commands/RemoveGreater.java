package server.commands;

import data.Ticket;
import exceptions.CollectionEmptyException;
import exceptions.EmptyException;
import exceptions.IncorrectInputException;
import exceptions.WrongArgumentInputException;
import server.utility.CollectionManager;

import java.time.LocalDateTime;

/**
 * Remove all greater tickets.
 */

public class RemoveGreater extends AbstractCommand {
    private CollectionManager collectionManager;
    private TicketChecker ticketChecker;

    public RemoveGreater(CollectionManager collectionManager, TicketChecker ticketChecker) {
        super("remove_greater {element}", "удалить из коллекции все элементы, превышающие заданный");
        this.collectionManager = collectionManager;
        this.ticketChecker = ticketChecker;
    }

    /**
     * Executes the command.
     *
     * @return Command exit status.
     */
    @Override
    public boolean execute(String argument) {
        try {
            if (!argument.isEmpty()) throw new WrongArgumentInputException();
            if (collectionManager.collectionSize() == 0) throw new CollectionEmptyException();
            Ticket ticketToFind = new Ticket(collectionManager.createNextId(), ticketChecker.checkName(),
                    ticketChecker.returnCoordinates(), LocalDateTime.now(), ticketChecker.checkPrice(),
                    ticketChecker.checkDiscount(), ticketChecker.checkTicketType(), ticketChecker.returnPerson());
            Ticket ticketToDelete = collectionManager.getByValue(ticketToFind);
            if (ticketToDelete == null) throw new EmptyException();
            collectionManager.removeGreater(ticketToFind);
            System.out.println("Р‘РёР»РµС‚С‹ СѓРґР°Р»РµРЅС‹");
            return true;
        } catch (WrongArgumentInputException exception) {
            System.out.println("Р�СЃРїРѕР»СЊР·РѕРІР°РЅРёРµ: " + getName());
        } catch (CollectionEmptyException exception) {
            System.err.println("РљРѕР»Р»РµРєС†РёСЏ РїСѓСЃС‚Р°!");
        } catch (EmptyException exception) {
            System.err.println("РўР°РєРёС… Р±РёР»РµС‚РѕРІ РІ РєРѕР»Р»РµРєС†РёРё РЅРµС‚!");
        } catch (IncorrectInputException e) {}
        return false;
    }
}
