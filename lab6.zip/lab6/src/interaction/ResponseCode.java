package interaction;

/**
 * Enum of response codes
 */
public enum ResponseCode {
    OK,
    ERROR,
    SERVER_EXIT
}
