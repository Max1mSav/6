package exceptions;

public class EmptyException extends Exception {
}
