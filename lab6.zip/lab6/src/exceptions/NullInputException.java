package exceptions;

public class NullInputException extends Exception {
}
