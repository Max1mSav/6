package exceptions;

public class IncorrectInputException extends Exception {
}
