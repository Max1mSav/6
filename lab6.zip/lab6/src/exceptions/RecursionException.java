package exceptions;

public class RecursionException extends Throwable {
}
