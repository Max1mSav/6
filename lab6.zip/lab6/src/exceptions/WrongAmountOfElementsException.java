package exceptions;

/**
 * Is throwed when wrong amount of elements.
 */

public class WrongAmountOfElementsException extends Exception {
}
