package exceptions;

/**
 * Is throwed when collection is empty.
 */

public class CollectionEmptyException extends Exception {
}
