package exceptions;

/**
 * Is throwed when wrong amount of elements.
 */

public class WrongArgumentInputException extends Exception {
}
